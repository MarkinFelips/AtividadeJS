var Celsius = parseFloat(prompt("Insira a temperatura em graus Celsius:"));

var Fahrenheit = F = (Celsius * 9/5) + 32;

alert(`A temperatura em Fahrenheit é: ${Fahrenheit}`);