var metros = parseFloat(prompt("Insíra o número em metros: "));

var centimetros = metros * 100;

alert(metros + " em metros é igual à " + centimetros + " centimetros");