var num1 = parseFloat(prompt("Porfavor insira o primeiro número:"));

var num2 = parseFloat(prompt("Porfavor insira o segundo número"));

var sum = num1 + num2;

alert("A soma dos dois números é " + sum);