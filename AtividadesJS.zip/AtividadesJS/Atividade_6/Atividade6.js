const raio = parseFloat(prompt("Insira o raio do circulo:"));

const área = Math.PI * raio * raio;

alert(`A área do circulo é: ${área}`);