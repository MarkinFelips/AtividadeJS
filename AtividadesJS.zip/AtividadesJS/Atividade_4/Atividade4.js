var nota1 = parseFloat(prompt("Coloque a primeira nota bismestral:"));
var nota2 = parseFloat(prompt("Coloque a segunda nota bimestral:"));
var nota3 = parseFloat(prompt("Coloque a terceira nota bimestral:"));
var nota4 = parseFloat(prompt("Coloque a quarta nota bimestral:"));

var NotaMédia = (nota1 + nota2+ nota3 + nota4) / 4;

alert("A média das notas é: " + NotaMédia.toFixed(2));