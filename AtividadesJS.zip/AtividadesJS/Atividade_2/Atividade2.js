var num = prompt("Porfavor insira um número:");

alert("O número inserido é: " + num + ".");