var ganho = parseFloat(prompt("Insira quanto você ganha por hora:"));

var mêsTrabalhado = parseFloat(prompt("insira o número de horas trabalhadas no mês:"));

var Total = ganho * mêsTrabalhado;

alert(`O ganho total do mês será: ${Total}`);