var Fahrenheit = parseFloat(prompt("Insira quantos graus fahrenheit:"));

var Celsius = C = 5 * ((Fahrenheit-32) / 9);

alert(`A temperatura em Celsius é: ${Celsius}`);