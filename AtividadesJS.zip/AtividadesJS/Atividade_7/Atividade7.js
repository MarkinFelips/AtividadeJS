const lado = parseFloat(prompt("Insira o lado do quadrado:"));

const área = lado * lado;

alert(`A área do quadrado é: ${área}`);